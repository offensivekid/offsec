# 🚂 Railway Deployment Guide

## Быстрый деплой на Railway.app

### 1️⃣ Создай проект на Railway

1. Зайди на https://railway.app
2. Нажми "New Project"
3. Выбери "Deploy from GitHub repo" или "Empty Project"

### 2️⃣ Загрузи код

**Вариант A: Через GitHub**
1. Push код в свой GitHub репозиторий
2. Подключи репо в Railway
3. Railway автоматически задеплоит

**Вариант B: Через Railway CLI**
```bash
npm install -g @railway/cli
railway login
railway init
railway up
```

### 3️⃣ Настрой Environment Variables

В Railway Dashboard → Settings → Variables добавь:

```bash
# ОБЯЗАТЕЛЬНЫЕ
SESSION_SECRET=твой-супер-секретный-ключ-здесь-минимум-32-символа
ADMIN_PASSWORD=твой-сильный-пароль-здесь

# ОПЦИОНАЛЬНО
ADMIN_USERNAME=admin
ADMIN_EMAIL=admin@offensive-forum.local
NODE_ENV=production
PORT=3000
```

**ВАЖНО:** 
- `SESSION_SECRET` - сгенерируй случайную строку минимум 32 символа
- `ADMIN_PASSWORD` - сильный пароль для админа

### 4️⃣ Деплой!

Railway автоматически:
- ✅ Установит зависимости (`npm install`)
- ✅ Запустит сервер (`npm start`)
- ✅ **Автоматически создаст БД** при первом запуске
- ✅ Создаст админа с твоим паролем из .env
- ✅ Сгенерирует тестовый access key

### 5️⃣ Проверь логи

В Railway Dashboard → Deployments → Logs найди:

```
✅ Admin user created: admin
⚠️  Default password: твой-пароль
🔑 Sample access key: XXXX-XXXX-XXXX-XXXX
```

**ЗАПОМНИ** этот access key!

### 6️⃣ Открой сайт

Railway даст тебе URL типа:
```
https://offensive-forum-production.up.railway.app
```

Открой и тестируй!

## 📊 Что происходит при первом запуске:

1. Сервер стартует
2. Проверяет есть ли таблицы в БД
3. Если нет - **автоматически создаёт**:
   - Все таблицы (users, threads, replies, keys, siem_events)
   - Админ аккаунт с паролем из .env
   - 2 примера тем (публичная + приватная)
   - 1 тестовый access key
4. Выводит в логи access key
5. Готово!

## 🔑 Тестирование:

### Как админ:
1. Login
2. Username: `admin` (или что указал в .env)
3. Password: твой пароль из .env
4. Получишь админ-панель + корону 👑

### Создать юзера с приватным доступом:
1. Register нового юзера
2. Login с access key из логов
3. Получишь доступ к приватным темам!

## ⚠️ Важно для Railway:

### Persistence данных:
Railway использует **ephemeral filesystem** - при каждом деплое БД сбросится!

**Решения:**
1. **Railway Volume** (платная фича):
   - Settings → Volume → Add Volume
   - Mount path: `/app/data`
   - В .env: `DB_PATH=/app/data/database.sqlite`

2. **External DB** (рекомендуется):
   - Используй Railway Postgres
   - Замени SQLite на PostgreSQL
   - БД будет персистентной

### Для production без Volume:

БД будет сбрасываться при каждом деплое, но:
- Админ всегда будет доступен (создаётся автоматом)
- Access key будет новый каждый раз (смотри логи)
- **Подходит для demo/testing**, не для production

## 🐛 Troubleshooting:

### Ошибка: "Session secret DEFAULT"
**Решение:** Добавь `SESSION_SECRET` в Railway Variables

### Ошибка: "no such table: threads"
**Решение:** Перезапусти деплой - БД инициализируется автоматически

### Не могу залогиниться как админ
**Проверь логи:** Там будет пароль админа
**Решение:** Убедись что `ADMIN_PASSWORD` в Variables совпадает с тем что ты вводишь

### Access key не работает
**Проверь логи:** Новый ключ генерируется при каждом деплое
**Решение:** Скопируй актуальный ключ из логов Railway

## 📝 Полезные команды Railway CLI:

```bash
# Логи в реальном времени
railway logs

# Открыть сайт
railway open

# Перезапустить
railway restart

# Environment variables
railway variables
```

## 🎯 Production Checklist:

- [ ] `SESSION_SECRET` - случайная строка 32+ символов
- [ ] `ADMIN_PASSWORD` - сильный пароль
- [ ] `NODE_ENV=production`
- [ ] Railway Volume настроен (если нужна персистентность)
- [ ] HTTPS включен (автоматически на Railway)
- [ ] Backup access keys перед редеплоем

## 💡 Tips:

- **Access keys сбрасываются** при редеплое (если нет Volume)
- **Генерируй новые ключи** через Admin Panel после деплоя
- **Делай backup** важных данных
- Для **production** используй Railway Postgres вместо SQLite

---

**Готово! Форум работает на Railway! 🚀**
