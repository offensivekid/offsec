# 🔒 offensive-forum v2.0 - Local Database Edition

Защищённый форум с полной системой регистрации/логина и локальной SQLite базой данных.

## 🎯 Основные изменения v2.0

### ✅ Убран Firebase - добавлена локальная БД
- **SQLite database** вместо Firebase
- **Полная система регистрации** с email и паролем
- **Bcrypt хэширование** паролей
- **Express backend** с REST API
- **Session-based auth** с cookies

### ✅ Система доступа к приватным темам
- **Публичные темы**: Создают ВСЕ зарегистрированные пользователи
- **Приватные темы**: 
  - Создают ТОЛЬКО админы
  - Видят админы + пользователи с **специальным ключом доступа**
  - Обычные пользователи НЕ видят приватные темы (даже если залогинены)

### ✅ Типы пользователей:

1. **Обычный юзер** (зарегистрирован без ключа):
   - ✅ Видит публичные темы
   - ✅ Создаёт публичные темы
   - ❌ НЕ видит приватные темы
   
2. **Юзер с ключом доступа** (использовал access key при логине):
   - ✅ Видит ВСЕ темы (публичные + приватные)
   - ✅ Создаёт публичные темы
   - ✅ Отвечает на приватные темы
   - ❌ НЕ может создавать приватные темы
   
3. **Админ**:
   - ✅ Видит ВСЕ темы
   - ✅ **Создаёт приватные темы** (ТОЛЬКО АДМИН!)
   - ✅ Создаёт публичные темы
   - ✅ Генерирует ключи доступа
   - ✅ Админ-панель со статистикой

## 🚀 Быстрый старт

### Локально:

```bash
npm install
npm start  # БД инициализируется автоматически!
```

### На Railway.app:

Читай **RAILWAY-DEPLOY.md** для полной инструкции.

Кратко:
1. Push в GitHub
2. Подключи к Railway
3. Добавь переменные: `SESSION_SECRET`, `ADMIN_PASSWORD`
4. Деплой! (БД создастся автоматически)

---

## 🔧 Локальная разработка

### 1. Установка зависимостей

```bash
npm install
```

### 2. Настройка (опционально)

Отредактируй `.env` и измени:
- `SESSION_SECRET` - секрет для сессий (ОБЯЗАТЕЛЬНО смени!)
- `ADMIN_USERNAME` - имя админа
- `ADMIN_PASSWORD` - пароль админа (ОБЯЗАТЕЛЬНО смени!)
- `ADMIN_EMAIL` - email админа

```env
SESSION_SECRET=your-super-secret-key-here-32-chars-minimum
ADMIN_USERNAME=admin
ADMIN_PASSWORD=your-strong-password-here
ADMIN_EMAIL=admin@offensive-forum.local
```

### 3. Запуск сервера

```bash
npm start
```

**БД инициализируется автоматически** при первом запуске!

Или для разработки (с auto-reload):

```bash
npm run dev
```

### 4. Открой браузер

```
http://localhost:3000
```

В консоли увидишь:
- ✅ Админ аккаунт создан
- 🔑 Тестовый access key (запомни его!)

## 📱 Использование

### Регистрация нового пользователя:

1. Нажми "Login"
2. Нажми "Don't have an account? Register"
3. Заполни:
   - Username (3-50 символов, только a-z, 0-9, _, -)
   - Email
   - Password (минимум 6 символов)
4. Регистрация!

### Вход обычного пользователя:

1. Нажми "Login"
2. Введи username и password
3. **НЕ вводи** access key (оставь пустым)
4. Войдёшь как обычный юзер (видишь только публичные темы)

### Вход с ключом доступа (для приватных тем):

1. Нажми "Login"
2. Введи username и password
3. **Введи access key** (формат: XXXX-XXXX-XXXX-XXXX)
4. Войдёшь с доступом к приватным темам!

### Вход как админ:

1. Используй credentials из `.env`:
   - Username: `admin` (или что указал)
   - Password: `admin123` (или что указал)
2. Получишь админ-панель и корону 👑

## 🔑 Ключи доступа

### Как работает:

1. **Админ генерирует ключи** (Admin Panel → Generate Keys)
2. **Админ даёт ключ пользователю** (в личку, на форуме, и т.д.)
3. **Пользователь логинится с ключом**:
   - Поле "Access Key" при входе
   - Вводит ключ → получает доступ к приватным темам
4. **Ключ деактивируется** после использования (one-time use)

### Генерация ключей:

1. Войди как админ
2. Перейди в Admin Panel
3. Укажи количество (1-50)
4. Нажми Generate
5. Скопируй ключи и раздай нужным людям

## 🛡️ Безопасность

### Реализованная защита:

✅ **Bcrypt password hashing** (12 rounds)
✅ **Express-session** с secure cookies
✅ **Helmet.js** для security headers
✅ **CSRF protection** через session
✅ **Rate limiting** (100 req/min)
✅ **XSS protection** - input sanitization
✅ **SQL Injection protection** - prepared statements
✅ **Input validation** на сервере
✅ **Access control** - проверка прав на каждый endpoint
✅ **SIEM logging** всех событий безопасности

### Logged events:

- User registration
- Failed/successful logins
- XSS attempts
- Unauthorized access attempts
- Thread creation
- Reply creation
- Key generation
- Key usage
- Admin actions

## 📊 Структура БД

### Tables:

- **users**: пользователи (username, email, password_hash, is_admin, has_private_access)
- **sessions**: сессии (для express-session)
- **threads**: темы (title, body, author_id, is_private)
- **replies**: ответы (thread_id, author_id, text)
- **access_keys**: ключи доступа (key_code, is_active, created_by, used_by)
- **siem_events**: события безопасности (event_type, severity, user_id, details)

## 🔧 Технологии

### Backend:
- Node.js + Express
- SQLite (better-sqlite3)
- Bcrypt (password hashing)
- Express-session (auth)
- Helmet (security headers)
- Express-rate-limit (DDoS protection)

### Frontend:
- Vanilla JS (ES6)
- Pure CSS
- No frameworks
- JetBrains Mono font

## ⚙️ API Endpoints

### Auth:
- `POST /api/auth/register` - регистрация
- `POST /api/auth/login` - вход (+ опционально access key)
- `POST /api/auth/logout` - выход
- `GET /api/auth/me` - текущий пользователь

### Threads:
- `GET /api/threads` - все доступные темы
- `GET /api/threads/:id` - конкретная тема
- `POST /api/threads` - создать тему (auth required)
- `GET /api/threads/:id/replies` - ответы на тему
- `POST /api/threads/:id/replies` - добавить ответ (auth required)

### Admin:
- `POST /api/admin/keys/generate` - генерация ключей (admin only)
- `GET /api/admin/keys` - список всех ключей (admin only)
- `GET /api/admin/stats` - статистика (admin only)

## ⚠️ Важно

1. **ОБЯЗАТЕЛЬНО смени** `SESSION_SECRET` в `.env`
2. **ОБЯЗАТЕЛЬНО смени** `ADMIN_PASSWORD` в `.env`
3. **Для production**: используй HTTPS
4. **Для production**: настрой `NODE_ENV=production`
5. **БД файл**: `database.sqlite` - делай backup!

## 🌐 Деплой на сервер

### VPS (Ubuntu/Debian):

```bash
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Clone и setup
git clone your-repo
cd offensive-forum
npm install

# Setup .env
nano .env
# (измени секреты!)

# Init DB
npm run init-db

# Install PM2
sudo npm install -g pm2

# Start
pm2 start server.js --name offensive-forum
pm2 save
pm2 startup

# Setup nginx reverse proxy
sudo apt install nginx
# ... nginx config ...
```

### Docker:

```bash
# TODO: добавить Dockerfile
```

## 📝 Roadmap

- [ ] Dockerfile для деплоя
- [ ] Email verification
- [ ] Password reset
- [ ] 2FA
- [ ] File attachments
- [ ] User profiles
- [ ] Thread editing/deletion
- [ ] Moderation tools
- [ ] IP banning
- [ ] Thread categories

## 📄 Лицензия

MIT License - используй как хочешь!

---

**Сделано с ❤️ и заботой о безопасности**

**Версия 2.0** - Local Database Edition
