# 🔥 Offensive Forum - ГОТОВ К ДЕПЛОЮ

Форум с приватными тредами и SQLite базой данных.

## 🚀 Быстрый деплой на Railway

### 1. Подготовка

1. Залейте этот код на GitHub
2. Зайдите на [Railway.app](https://railway.app)
3. Нажмите "New Project" → "Deploy from GitHub repo"
4. Выберите ваш репозиторий

### 2. Настройка переменных окружения

В Railway добавьте эти переменные (Variables):

```
SESSION_SECRET=ваш-случайный-секрет-минимум-32-символа
NODE_ENV=production
```

**Важно:** `SESSION_SECRET` должен быть длинной случайной строкой. Например:
```
SESSION_SECRET=kJ8mN3pQ9rT2vX5yZ7aB4cD6eF8gH0iJmN3pQ9rT2vX5
```

### 3. Деплой

Railway автоматически:
- Установит зависимости
- Запустит `npm start`
- Назначит публичный URL

## ✅ Что исправлено

- ✅ Добавлен fallback для `SESSION_SECRET`
- ✅ Порт настроен для Railway (`PORT=8080`)
- ✅ Добавлен bind на `0.0.0.0` для внешних подключений
- ✅ Создан `.gitignore` для безопасности
- ✅ Создан `.env.example` с примерами переменных

## 📦 Локальный запуск

```bash
npm install
cp .env.example .env
# Отредактируйте .env и установите SESSION_SECRET
npm start
```

Откройте: http://localhost:8080

## 🔐 Доступы по умолчанию

- **Админ:** `admin` / `adminpass123`
- **Регистрационный ключ:** `IMXY-JHGB-WF49-W5JN` (генерируется при старте)

## 📁 Структура

```
offensive-forum/
├── server.js          # Основной сервер
├── package.json       # Зависимости
├── public/           # Фронтенд
│   ├── index.html
│   ├── app.js
│   └── styles.css
├── .env.example      # Пример переменных окружения
└── .gitignore        # Игнорируемые файлы
```

## 🛠 Технологии

- Express.js
- SQLite (better-sqlite3)
- bcrypt для хеширования паролей
- express-session для сессий
- Helmet для безопасности
- Rate limiting

## 🔥 Готово!

Просто запушьте на GitHub и задеплойте через Railway. Всё будет работать из коробки!
